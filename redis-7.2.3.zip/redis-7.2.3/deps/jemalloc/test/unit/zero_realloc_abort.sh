#!/bin/sh

export MALLOC_CONF="zero_realloc:abort"
